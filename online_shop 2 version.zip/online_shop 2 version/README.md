
# Start server

npm run serve

# Start json

json-server --watch db.json