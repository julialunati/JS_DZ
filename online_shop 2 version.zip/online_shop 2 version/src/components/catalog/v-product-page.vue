<template>
  <div class="v-product-page">
    <router-link :to="{ name: 'catalog' }" class="nav-inside go-to-catalog">
      GO TO CATALOG <i class="fas fa-angle-double-right"></i>
    </router-link>
    <div class="product-page-info">
      <img
        v-if="product.image"
        class="v-catalog-item__image enlarge"
        :src="require('../../assets/images/' + product.image)"
        alt="img"
      />
      <div class="additional-info">
        <p>Product name: {{ product.name }}</p>
        <p>Article: {{ product.article }}</p>
        <p>Product detail: 96% Cotton, 4% Elastane. Machine wash.</p>
        <p>Model's height is 5'9 and he wears a size 8.</p>
        <p>Price: {{ product.price | toFix | formattedPrice }}</p>
        <button class="v-catalog-item__add_to_cart_btn btn" @click="addToCart">
          Add to cart
        </button>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import toFix from "../../filters/toFix";
import formattedPrice from "../../filters/price-format";

export default {
  name: "v-product-page",
  props: {},
  data() {
    return {};
  },
  filters: {
    formattedPrice,
    toFix,
  },
  computed: {
    ...mapGetters(["PRODUCTS"]),
    product() {
      let result = {};
      let vm = this;
      this.PRODUCTS.find(function (item) {
        if (item.article === vm.$route.query.product) {
          result = item;
        }
      });
      return result;
    },
  },
  methods: {
    ...mapActions(["GET_PRODUCTS_FROM_API", "ADD_TO_CART"]),
    addToCart() {
      this.ADD_TO_CART(this.product);
    },
  },
  mounted() {
    if (!this.PRODUCTS.length) {
      this.GET_PRODUCTS_FROM_API();
    }
  },
};
</script>

<style scoped>
.go-to-catalog {
  text-align: center;
  display: inline-block;
  height: 50px;
  padding-top: 30px;
}
.v-product-page {
  text-align: center;
  min-height: 65vh;
}

.product-page-info {
  max-width: 700px;
}

.additional-info {
  font-size: 14px;
  float: right;
  max-width: 280px;
  text-align: left;
}
@media (max-width: 660px) {
  .additional-info {
    float: none;
    min-width: 98%;
    text-align: center;
  }
}

.enlarge {
  width: 350px;
}

@media (max-width: 660px) {
  .enlarge {
    width: 300px;
  }
}


</style>
