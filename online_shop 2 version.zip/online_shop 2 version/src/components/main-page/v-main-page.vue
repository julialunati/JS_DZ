<template>
  <div class="v-main-page">
     <div class="nav">
      <router-link :to="{ name: 'catalog' }" class="nav-inside">
        BROWSE ALL PRODUCTS <i class="fas fa-angle-double-right"></i>
      </router-link>
    </div>
    <div class="promo">
      <div class="promo-text">
        <div>THE BRAND</div>
        OF LUXERIOUS <span>FASHION</span>
      </div>
    </div>
    <div class="feature">
      <div class="featureMain">
        <div class="featureOffer">
          <div class="offerText">
            10% <span class="offerTextPink">DISCOUNT </span>
          </div>
          <div class="offerTextSmall">on your first order</div>
        </div>
        <div class="featureOther">
          <div class="features">
            <img
              class="featuresImg"
              src="../../assets/forma1.png"
              alt="forma"
            />
            <div class="featuresTitle">Free Delivery</div>
            <div class="featuresDesc">
              Worldwide delivery on all. Authorit tively morph next-generation
              innov tion with extensive models.
            </div>
          </div>
          <div class="features">
            <img
              class="featuresImg"
              src="../../assets/forma2.png"
              alt="forma"
            />
            <div class="featuresTitle">Sales &amp; discounts</div>
            <div class="featuresDesc">
              Worldwide delivery on all. Authorit tively morph next-generation
              innov tion with extensive models.
            </div>
          </div>
          <div class="features">
            <img
              class="featuresImg"
              src="../../assets/forma3.png"
              alt="forma"
            />
            <div class="featuresTitle">Quality assurance</div>
            <div class="featuresDesc">
              Worldwide delivery on all. Authorit tively morph next-generation
              innov tion with extensive models.
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="subscribe">
      <div class="subscribeContent">
        <div class="subscribeLeft">
          <img class="imgUser" src="../../assets/face.png" alt="user.photo" />
          <div class="infUser">
            <div class="comment">
              “Vestibulum quis porttitor dui! Quisque viverra nunc mi, a
              pulvinar purus condimentum a. Aliquam condimentum mattis neque sed
              pretium”
            </div>
            <div class="userInfo">
              <div class="userName">Bin Burhan</div>
              Dhaka, Bd
            </div>
            <div class="scrollReview">
              <div class="scroll"></div>
              <div class="scroll"></div>
              <div class="scroll"></div>
            </div>
          </div>
        </div>
        <div class="subscribeRight">
          <div class="subscribe1">SUBSCRIBE</div>
          <div class="subscribe2">FOR OUR NEWLETTER AND PROMOTION</div>
          <form class="emailForm" action="#">
            <input type="email" placeholder="Enter Your Email" /><button>
              Subscribe
            </button>
          </form>
        </div>
      </div>
    </div>
    <div class="footer">
      <div class="footerContent">
        <div class="brandInfo">
          <div class="logo">BRAN<span class="logo-name d">D</span></div>
          <div class="about">
            <p>
              Objectively transition extensive data rather than cross functional
              solutions. Monotonectally syndicate multidisciplinary materials
              before go forward benefits. Intrinsicly syndicate an expanded
              array of processes and cross-unit partnerships.
            </p>
            <p>
              Efficiently plagiarize 24/365 action items and focused
              infomediaries.Distinctively seize superior initiatives for
              wireless technologies. Dynamically optimize.
            </p>
          </div>
        </div>
        <div class="otherInfo">
          <div class="company">
            <div class="footerTitle">COMPANY</div>
            <a href="#" class="footerLink">Home</a>
            <a href="#" class="footerLink">Shop</a>
            <a href="#" class="footerLink">About</a>
            <a href="#" class="footerLink">How It Works</a>
            <a href="#" class="footerLink">Contact</a>
          </div>
          <div class="information">
            <div class="footerTitle">INFORMATION</div>
            <a href="#" class="footerLink">Tearms &amp; Condition</a>
            <a href="#" class="footerLink">Privacy Policy</a>
            <a href="#" class="footerLink">How to Buy</a>
            <a href="#" class="footerLink">How to Sell</a>
            <a href="#" class="footerLink">Promotion</a>
          </div>
          <div class="shopCategory">
            <div class="footerTitle">SHOP CATEGORY</div>
            <a href="#" class="footerLink">Men</a>
            <a href="#" class="footerLink">Women</a>
            <a href="#" class="footerLink">Child</a>
            <a href="#" class="footerLink">Apparel</a>
            <a href="#" class="footerLink">Brows All</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "v-main-page",
  props: {},
  data() {
    return {};
  },
  computed: {},
};
</script>

<style>
.nav {
  min-height: 50px;
  display: flex;
  justify-content: center;
  align-items: center;
}

.nav-inside {
  height: 20px;
  font-family: "Lato", sans-serif;
  font-size: 16px;
  font-weight: 600;
  color: #222222;
  text-decoration: none;
}

.nav-inside:hover {
  color: #f16d7f;
}

.promo {
  height: 540px;
  background: url(../../assets/slider.png) no-repeat;
  background-color: #e8e8e8;
  display: flex;
  align-items: center;
}

@media (max-width: 1361px) {
  .promo {
    background: url(../../assets/slider.png) no-repeat -400px;
    background-color: #e8e8e8;
  }
}

@media (max-width: 965px) {
  .promo {
    background: url(../../assets/slider.png) no-repeat -800px;
    background-color: #e8e8e8;
  }
}

.promo-text {
  height: 92px;
  font-family: "Lato", sans-serif;
  border-left: 12px solid #f16d7f;
  padding-left: 12px;
  font-size: 40px;
  font-weight: 900;
  letter-spacing: 1px;
  color: #222222;
  margin-right: 2px;
  margin-left: 60px;
}

@media (max-width: 537px) {
  .promo-text {
    font-size: 22px;
  }
}

.promo-text div {
  font-family: "Lato", sans-serif;
  font-size: 60px;
  font-weight: 900;
  line-height: 44px;
  letter-spacing: 1.5px;
  margin-bottom: 8px;
}

@media (max-width: 537px) {
  .promo-text div {
    font-size: 42px;
  }
}

.promo-text span {
  color: #f16d7f;
}

.featureMain {
  width: 80%;
  height: 529px;
  padding-bottom: 100px;
  padding-top: 100px;
  margin: 0 auto;
  display: flex;
}

@media (max-width: 1188px) {
  .featureMain {
    flex-direction: column;
    align-items: center;
  }
}

@media (max-width: 800px) {
  .featureMain {
  width: 100%;
  }
}

.featureOffer {
  height: inherit;
  width: 767px;
  margin: 0;
  background: url(../../assets/man.png) no-repeat -200px;
  outline: 1px solid #222224;
}

@media (max-width: 1188px) {
  .featureOffer {
    background: url(../../assets/man.png) no-repeat -200px -20px;
    flex-direction: column;
    height: 400px;
  }
}

@media (max-width: 800px) {
  .featureOffer {
  width: 550px;
  }
}

@media (max-width: 581px) {
  .featureOffer {
    width: 300px;
    background: #222224;
    max-height: 250px;
  }
  .offerText{
    padding-top: 20px;
  }
}

.offerText {
  font-family: "Lato", sans-serif;
  font-size: 39.7px;
  line-height: 1.2;
  font-weight: 700;
  letter-spacing: 0.025em;
  color: #ffffff;
  padding-top: 145px;
  padding-left: 40px;
}

@media (max-width: 1188px) {
  .offerText {
    font-size: 30px;
  }
}
@media (max-width: 581px) {
  
  .offerText{
    padding-top: 40px;
    padding-bottom: 20px;
  }
}

.offerText .offerTextPink {
  color: #f16d7f;
}

.offerTextSmall {
  font-size: 22px;
  font-weight: 700;
  color: #ffffff;
  padding-left: 40px;
}

.featureOther {
  height: 469px;
  width: 373px;
  background-color: #222224;
  margin: 0;
  outline: 1px solid #222224;
  display: flex;
  flex-direction: column;
  justify-content: space-around;
  align-items: stretch;
  padding-bottom: 60px;
}

@media (max-width: 1188px) {
  .featureOther {
    width: 767px;
    height: 260px;
  }
}

@media (max-width: 800px) {
  .featureOther {
  width: 550px;
  }
}

@media (max-width: 581px) {
  .featureOther {
    width: 300px;
    min-height:300px;
  }
}

.features {
  position: relative;
}

.featuresTitle {
  font-family: "Lato", sans-serif;
  font-size: 20px;
  line-height: 1.2;
  font-weight: 700;
  letter-spacing: 0.025em;
  color: #fbfbfb;
  position: absolute;
  float: right;
  left: 110px;
  top: 8px;
}

@media (max-width: 1188px) {
  .featuresTitle {
    font-size: 14px;
  }
}

.featuresDesc {
  font-family: "Lato", sans-serif;
  font-size: 14px;
  line-height: 24px;
  font-weight: 300;
  letter-spacing: 0.025em;
  color: #fbfbfb;
  position: absolute;
  float: right;
  left: 110px;
  top: 35px;
  right: 35px;
}

@media (max-width: 1188px) {
  .featuresDesc {
    font-size: 12px;
    line-height: 14px;
  }
}

.featuresImg {
  padding-left: 35px;
  padding-right: 30px;
}

.subscribe {
  min-height: 438px;
  margin: 0 auto;
  background: url(../../assets/sub.png) no-repeat center bottom, #ccc;
  background-blend-mode: overlay;
  background-size: cover;
  display: flex;
  align-items: center;
  justify-content: center;
}

.subscribeContent {
  width: 71.25%;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

@media (max-width: 1280px) {
  .subscribeContent {
    min-height: 300px;
    flex-direction: column;
    justify-content: space-between;
    align-items: center;
  }
}

@media (max-width: 500px) {
  .subscribeContent {
    flex-direction: column;
    justify-content: space-between;
    align-items: center;
    width: 90%;
    padding: 5%;
    margin: 0 auto;
  }
}

.subscribeLeft {
  min-width: 500px;
  display: flex;
  justify-content: space-between;
}

.subscribeLeft .imgUser {
  max-height: 83px;
}

@media (max-width: 580px) {
  .subscribeLeft {
    min-height: 270px;
    min-width: 300px;
    margin-bottom: 20px;
    flex-direction: column;
    justify-content: space-between;
    align-items: center;
  }
}

/* line 52, ../../../../../Users/juliamolokova/Documents/GeekBrains/3. Профессиональная верстка (июль 2020)/my project/scss/_subscribe.scss */
.comment {
  height: 68px;
  max-width: 386px;
  font-family: "Lato", sans-serif;
  font-size: 16px;
  line-height: 26px;
  font-weight: 400;
  font-style: italic;
  letter-spacing: 0.025em;
  color: #222224;
  margin-bottom: 15px;
}

@media (max-width: 580px) {
  /* line 52, ../../../../../Users/juliamolokova/Documents/GeekBrains/3. Профессиональная верстка (июль 2020)/my project/scss/_subscribe.scss */
  .comment {
    font-size: 14px;
    max-width: 320px;
  }
}

/* line 69, ../../../../../Users/juliamolokova/Documents/GeekBrains/3. Профессиональная верстка (июль 2020)/my project/scss/_subscribe.scss */
.userInfo {
  width: 90px;
  height: 27px;
  font-size: 12px;
  line-height: 10px;
  font-weight: 300;
  color: #222224;
  margin-bottom: 8%;
}

/* line 77, ../../../../../Users/juliamolokova/Documents/GeekBrains/3. Профессиональная верстка (июль 2020)/my project/scss/_subscribe.scss */
.userInfo .userName {
  font-family: "Lato", sans-serif;
  font-size: 15px;
  line-height: 20px;
  font-weight: 700;
  letter-spacing: 0.025em;
  color: #f16d7f;
}

/* line 89, ../../../../../Users/juliamolokova/Documents/GeekBrains/3. Профессиональная верстка (июль 2020)/my project/scss/_subscribe.scss */
.scrollReview {
  width: 160px;
}

/* line 93, ../../../../../Users/juliamolokova/Documents/GeekBrains/3. Профессиональная верстка (июль 2020)/my project/scss/_subscribe.scss */
.scroll {
  width: 38px;
  height: 5px;
  background-color: #d6d6d6;
  margin-right: 10px;
  display: inline-block;
}

/* line 100, ../../../../../Users/juliamolokova/Documents/GeekBrains/3. Профессиональная верстка (июль 2020)/my project/scss/_subscribe.scss */
.scroll:hover {
  background-color: #f16d7f;
}

/* line 105, ../../../../../Users/juliamolokova/Documents/GeekBrains/3. Профессиональная верстка (июль 2020)/my project/scss/_subscribe.scss */
.subscribe1 {
  font-size: 24px;
  line-height: 30px;
  font-weight: 400;
  letter-spacing: 0.025em;
  color: #222224;
}

@media (max-width: 340px) {
  /* line 105, ../../../../../Users/juliamolokova/Documents/GeekBrains/3. Профессиональная верстка (июль 2020)/my project/scss/_subscribe.scss */
  .subscribe1 {
    font-size: 20px;
  }
}

/* line 116, ../../../../../Users/juliamolokova/Documents/GeekBrains/3. Профессиональная верстка (июль 2020)/my project/scss/_subscribe.scss */
.subscribe2 {
  font-size: 14px;
  line-height: 24px;
  text-transform: none;
  letter-spacing: 0.025em;
  font-weight: 400;
  color: #222224;
}

@media (max-width: 340px) {
  /* line 116, ../../../../../Users/juliamolokova/Documents/GeekBrains/3. Профессиональная верстка (июль 2020)/my project/scss/_subscribe.scss */
  .subscribe2 {
    font-size: 12px;
  }
}

/* line 129, ../../../../../Users/juliamolokova/Documents/GeekBrains/3. Профессиональная верстка (июль 2020)/my project/scss/_subscribe.scss */
.subscribeRight {
  min-height: 125px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
}

/* line 138, ../../../../../Users/juliamolokova/Documents/GeekBrains/3. Профессиональная верстка (июль 2020)/my project/scss/_subscribe.scss */
.emailForm {
  height: 46px;
}

/* line 142, ../../../../../Users/juliamolokova/Documents/GeekBrains/3. Профессиональная верстка (июль 2020)/my project/scss/_subscribe.scss */
.emailForm input {
  height: inherit;
  width: 250px;
  border: none;
  outline: none;
  padding: 0 28px;
  font-weight: 700;
  background-color: #e1e1e1;
  border-top-left-radius: 23px;
  border-bottom-left-radius: 23px;
}

@media (max-width: 580px) {
  /* line 142, ../../../../../Users/juliamolokova/Documents/GeekBrains/3. Профессиональная верстка (июль 2020)/my project/scss/_subscribe.scss */
  .emailForm input {
    width: 150px;
  }
}

@media (max-width: 340px) {
  /* line 142, ../../../../../Users/juliamolokova/Documents/GeekBrains/3. Профессиональная верстка (июль 2020)/my project/scss/_subscribe.scss */
  .emailForm input {
    width: 100px;
    font-size: 12px;
  }
}

/* line 161, ../../../../../Users/juliamolokova/Documents/GeekBrains/3. Профессиональная верстка (июль 2020)/my project/scss/_subscribe.scss */
.emailForm button {
  background-color: #f16d7f;
  border-top-right-radius: 23px;
  border-bottom-right-radius: 23px;
  color: white;
  border: none;
  height: inherit;
  padding: 0 20px;
  outline: none;
  cursor: pointer;
}

@media (max-width: 340px) {
  .emailForm button {
    width: 100px;
    font-size: 12px;
  }
}

.footer {
  margin: 0 auto;
  min-height: 370px;
}

.footer .footerContent {
  width: 71.25%;
  margin: 0 auto;
  padding-top: 5%;
  display: flex;
  justify-content: space-between;
  background-color: #ffffff;
}

@media (max-width: 1359px) {
  .footer .footerContent {
    flex-direction: column;
    justify-content: space-between;
  }
}
@media (max-width: 800px) {
  .footer .footerContent {
  width: 80%;
  margin: 0 auto;
  padding-top: 5%;
  display: flex;
  justify-content: space-between;
  background-color: #ffffff;
}
}

/* line 22, ../../../../../Users/juliamolokova/Documents/GeekBrains/3. Профессиональная верстка (июль 2020)/my project/scss/_footer.scss */
.brandInfo {
  max-width: 37.47%;
  font-size: 14px;
  line-height: 24px;
  font-weight: 300;
  letter-spacing: 0.025em;
  color: #898989;
}

@media (max-width: 1359px) {
  /* line 22, ../../../../../Users/juliamolokova/Documents/GeekBrains/3. Профессиональная верстка (июль 2020)/my project/scss/_footer.scss */
  .brandInfo {
    min-width: 99%;
    margin: 0 auto;
  }
}

/* line 36, ../../../../../Users/juliamolokova/Documents/GeekBrains/3. Профессиональная верстка (июль 2020)/my project/scss/_footer.scss */
.about {
  margin-top: 15px;
}

/* line 40, ../../../../../Users/juliamolokova/Documents/GeekBrains/3. Профессиональная верстка (июль 2020)/my project/scss/_footer.scss */
.otherInfo {
  min-width: 50%;
  display: flex;
  justify-content: space-between;
}

@media (max-width: 1359px) {
  /* line 40, ../../../../../Users/juliamolokova/Documents/GeekBrains/3. Профессиональная верстка (июль 2020)/my project/scss/_footer.scss */
  .otherInfo {
    width: 99%;
    justify-content: space-evenly;
    margin: 0 auto;
  }
}

@media (max-width: 800px) {
  /* line 40, ../../../../../Users/juliamolokova/Documents/GeekBrains/3. Профессиональная верстка (июль 2020)/my project/scss/_footer.scss */
  .otherInfo {
    min-height: 900px;
    flex-direction: column;
    align-items: center;
    justify-content: space-evenly;
    margin: 0 auto;
  }
}

/* line 61, ../../../../../Users/juliamolokova/Documents/GeekBrains/3. Профессиональная верстка (июль 2020)/my project/scss/_footer.scss */
.company,
.information,
.shopCategory {
  min-height: 250px;
  min-width: 150px;
}

/* line 68, ../../../../../Users/juliamolokova/Documents/GeekBrains/3. Профессиональная верстка (июль 2020)/my project/scss/_footer.scss */
.footerLink {
  display: block;
  font-size: 16px;
  line-height: 42px;
  font-weight: 400;
  letter-spacing: 0.025em;
  color: #898989;
  text-decoration: none;
}

/* line 78, ../../../../../Users/juliamolokova/Documents/GeekBrains/3. Профессиональная верстка (июль 2020)/my project/scss/_footer.scss */
.footerLink:hover {
  color: #f16d7f;
}

/* line 82, ../../../../../Users/juliamolokova/Documents/GeekBrains/3. Профессиональная верстка (июль 2020)/my project/scss/_footer.scss */
.footerTitle {
  font-size: 18px;
  line-height: 26px;
  font-family: "Lato", sans-serif;
  font-weight: 700;
  letter-spacing: 0.025em;
  color: #f16d7f;
  padding-bottom: 30px;
}
</style>
