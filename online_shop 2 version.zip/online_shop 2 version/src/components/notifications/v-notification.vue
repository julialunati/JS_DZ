<template>
  <div class="v-notification">
    <transition-group name="v-transition-animate" class="messages_list">
      <div
        class="v-notification__content"
        v-for="message in messages"
        :key="message.id"
        :class="message.icon"
      >
        <div class="content__text">
          <span>{{ message.name }}</span>
          <i class="material-icons">{{ message.icon }}</i>
        </div>
        <div class="content_buttons">
          <button v-if="rightButton.length">{{ rightButton }}</button>
          <button v-if="leftButton.length">{{ leftButton }}</button>
        </div>
      </div>
    </transition-group>
  </div>
</template>

<script>
export default {
  name: "v-notification",
  props: {
    messages: {
      type: Array,
      default: () => {
        return [];
      },
    },
    rightButton: {
      type: String,
      default: "",
    },
    leftButton: {
      type: String,
      default: "",
    },
    timeout: {
      type: Number,
      default: 3000,
    },
  },
  data() {
    return {};
  },
  methods: {
    hideNotification() {
      let vm = this;
      if (this.messages.length) {
        setTimeout(function () {
          vm.messages.splice(vm.messages.length - 1, 1);
        }, vm.timeout);
      }
    },
  },
  watch: {
    messages() {
      this.hideNotification();
    },
  },
  mounted() {
    this.hideNotification();
  },
};
</script>

<style>
.v-notification {
  position: fixed;
  top: 80px;
  right: 16px;
  z-index: 10;
}
.v-notification__messages_list {
  display: flex;
  flex-direction: column-reverse;
}
.v-notification__content {
  padding: 16px;
  border-radius: 8px;
  color: #ffffff;
  display: flex;
  justify-content: space-between;
  align-items: center;
  height: 35px;
  margin-bottom: 16px;
  background: #f16d7f;
}
.error {
  background: red;
}
.warning {
  background: orange;
}
.check_circle {
  background: #f16d7f;
}

.content__text {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.v-transition-animate-enter {
  transform: translateX(120px);
  opacity: 0;
}
.v-transition-animate-enter-active {
  transition: all 0.6s ease;
}
.v-transition-animate-enter-to {
  opacity: 1;
}

.v-transition-animate-leave {
  height: 50px;
  opacity: 0.6;
}
.v-transition-animate-leave-active {
  transition: transform 0.6s ease, opacity 0.6s, height 0.6s 0.2s;
}
.v-transition-animate-leave-to {
  height: 0;
  transform: translateX(120px);
  opacity: 0;
}

.v-transition-animate-move {
  transition: transform 0.6s ease;
}
</style>
