<template>
  <div class="v-footer">

      <div class="footerInside">
        <div class="textRights">© 2020 Brand All Rights Reserved.</div>
        <div class="social">
          <a href=""><i class="fab fa-facebook-f"></i></a>
          <a href=""><i class="fab fa-twitter"></i></a>
          <a href=""><i class="fab fa-linkedin-in"></i></a>
          <a href=""><i class="fab fa-pinterest-p"></i></a>
          <a href=""><i class="fab fa-google-plus-g"></i></a>
        </div>
      </div>
  </div>
</template>

<script>
export default {
  name: "footer",
  props: {},
};
</script>

<style>

.v-footer {
  margin: -80px 0 auto;
  margin-top:-80px;
  height: 80px; 
  background-color: #e6e6e6;
  margin: 0 auto;
}

.v-footer .footerInside {
  width: 71.25%;
  margin: 0 auto;
  display: flex;
  justify-content: space-between;
}

@media (max-width: 800px) {
  .v-footer .footerInside {
   max-height: 60px;
    flex-direction: column;
    align-items: center;
    justify-content: space-evenly;
    margin: 0 auto;
  }
}

.textRights {
  font-family: "Lato", sans-serif;
  font-size: 16px;
  line-height: 16px;
  font-weight: 400;
  letter-spacing: 0.025em;
  color: #7a7a7a;
  display: inline-block;
  clear: both;
  padding-top: 32px;
}

@media (max-width: 800px) {
  .textRights {
    padding-top: 20px;
    font-size: 14px;
  }
}

.social {
  display: flex;
  width: 200px;
  justify-content: space-between;
  float: right;
  padding-top: 25px;
}

.social a {
  text-decoration: none;
  color: #7a7a7a;
}

.fab {
  width: 32px;
  height: 32px;
  background: white;
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  text-align: center;
}

.social a:hover {
  color: #f16d7f;
}

</style>
