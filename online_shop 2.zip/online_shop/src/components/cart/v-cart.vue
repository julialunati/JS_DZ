<template>
  <div class="v-cart">
    <router-link :to="{ name: 'catalog' }">
      <div class="v-catalog__link_to_catalog">Back to catalog</div>
    </router-link>
    <h2 class="v-cart-title">Cart</h2>
    <p class="no-products" v-if="!cart_data.length">
      There are no products in cart...
    </p>
    <v-cart-item
      v-for="(item, index) in cart_data"
      :key="item.article"
      :cart_item_data="item"
      @deleteFromCart="deleteFromCart(index)"
      @increment="increment(index)"
      @decrement="decrement(index)"
    />
    <div class="v-cart__total">
      <p class="total__name">Total:</p>
      <p>{{ cartTotalCost | toFix | formattedPrice }}</p>
    </div>
  </div>
</template>

<script>
import vCartItem from "./v-cart-item";
import toFix from "../../filters/toFix";
import formattedPrice from "../../filters/price-format";
import { mapActions } from "vuex";

export default {
  name: "v-cart",
  components: {
    vCartItem,
  },
  props: {
    cart_data: {
      type: Array,
      default() {
        return [];
      },
    },
  },
  data() {
    return {};
  },
  filters: {
    formattedPrice,
    toFix,
  },
  computed: {
    cartTotalCost() {
      let result = [];

      if (this.cart_data.length) {
        for (let item of this.cart_data) {
          result.push(item.price * item.quantity);
        }

        result = result.reduce(function (sum, el) {
          return sum + el;
        });
        return result;
      } else {
        return 0;
      }
    },
  },
  methods: {
    ...mapActions([
      "DELETE_FROM_CART",
      "INCREMENT_CART_ITEM",
      "DECREMENT_CART_ITEM",
    ]),
    increment(index) {
      this.INCREMENT_CART_ITEM(index);
    },
    decrement(index) {
      this.DECREMENT_CART_ITEM(index);
    },
    deleteFromCart(index) {
      this.DELETE_FROM_CART(index);
    },
  },
};
</script>

<style>
.v-cart {
  min-height: 700px;
}

.no-products {
  text-align: center;
  padding-top: 100px;
}

.v-catalog__link_to_catalog {
  position: fixed;
  top: 28px;
  right: 10px;
  padding: 16px;
  width: 80px;
  font-weight: normal;
  letter-spacing: 0.68px;
  color: #222222;
}

.v-catalog__link_to_catalog:hover {
  color: #f16d7f;
}

.v-cart-title {
  text-align: center;
  opacity: 0.6;
}

.v-cart__total {
  position: fixed;
  bottom: 0;
  right: 0;
  left: 0;
  padding: 16px 24px;
  display: flex;
  justify-content: center;
  background: #f16d7f;
  color: #ffffff;
  font-size: 20px;
}

.total__name {
  margin-right: 16px;
}
</style>
