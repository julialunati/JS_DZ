<template>
  <div class="v-main-wrapper">
    <div class="container">
    <v-header />
    <keep-alive>
      <router-view></router-view>
    </keep-alive>
    <div class="clr"></div>
    </div>
    <v-footer />
  </div>
</template>

<script>
  import vHeader from './layouts/v-header'
  import vFooter from './layouts/v-footer'
  export default {
    name: 'v-main-wrapper', 
    components: {
      vHeader,
      vFooter
    },
    props: {},
    data() {
      return {
        title: 'Main wrapper'
      }
    },
    computed: {},
    methods: {},
    watch: {}
  }
</script>

<style>

  .v-main-wrapper {
    height:100%;
  }

  .container{
    min-height:100%;
  }

  .clr{
    height: 80px;
  }
  
</style>
