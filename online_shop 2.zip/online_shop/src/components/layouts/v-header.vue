<template>
  <div class="v-header">
    <div class="v-header-inside">

        <router-link :to="{ name: 'mainPage' }">
          <div class="logo">BRAN<span class="logo-name d">D</span></div>
        </router-link>
        <div class="search-field">
          <input class ="search-input" type="text" v-model="searchValue" />
          <button class="search_btn">
            <i class="material-icons" @click="search(searchValue)">search</i>
          </button>
          <button class="search_btn">
            <i class="material-icons" @click="clearSearchField">cancel</i>
          </button>
      </div>
    </div>
  </div>
</template>

<script>
import { mapActions, mapGetters } from "vuex";

export default {
  name: "v-header",
  props: {},
  data() {
    return {
      searchValue: "",
    };
  },
  computed: {
    ...mapGetters(["SEARCH_VALUE"]),
  },
  methods: {
    ...mapActions(["GET_SEARCH_VALUE_TO_VUEX"]),
    search(value) {
      this.GET_SEARCH_VALUE_TO_VUEX(value);
      if (this.$route.path !== "/catalog") {
        this.$router.push("/catalog");
      }
    },
    clearSearchField() {
      this.searchValue = "";
      this.GET_SEARCH_VALUE_TO_VUEX();
      if (this.$route.path !== "/catalog") {
        this.$router.push("/catalog");
      }
    },
  },
};
</script>

<style>
.v-header {
  margin: 0 auto;
  min-height: 100px;
  background-color: #ffffff;
  border-bottom: 1px solid #ececec;
}

.v-header-inside {
  min-height: inherit;
  display: flex;
  justify-content: space-between;
  flex-wrap: nowrap;
  align-items: center;
  padding-left: 14.375%;
  padding-right: 14.375%;
}

@media (max-width: 1300px) {
  .v-header-inside {
    flex-wrap: wrap;
    margin: 0 auto;
    margin-bottom: 15px;
    margin-top: 15px;
  }
}

@media (max-width: 800px) {
  .v-header-inside {
    width: 250px;
    flex-wrap: wrap;
  }
}

.logo {
  width: 110px;
  background: url(logo.png) no-repeat;
  display: inline-block;
  height: 51px;
  font-size: 28px;
  line-height: 51px;
  font-weight: 300;
  letter-spacing: 0.68px;
  color: #222222;
  padding-left: 70px;
}

@media (max-width: 1300px) {
  .logo {
    margin-bottom: 15px;
  }
}

@media (max-width: 800px) {
  .logo {
    margin-bottom: 15px;
    margin-left: 22px;
  }
}

.logo .d {
  font-weight: 900;
  color: #f16d7f;
}


.search-field {
  font-family: "Lato", sans-serif;
  height: 38px;
  display: flex;
  border: 1px solid #e6e6e6;
  border-radius: 3px;
  overflow: hidden;
}

@media (max-width: 800px) {
  .searchForm {
    margin: 0 auto;
  }
}

.search-input {
  height: inherit;
  overflow: hidden;
  width: 200px;
  border: none;
  padding-left: 15px;
  font-family: "Lato", sans-serif;
  font-size: 14px;
  line-height: 32px;
  font-weight: 300;
  letter-spacing: 0.025em;
  color: #a4a4a4;
}

@media (max-width: 800px) {
  .searchForm input {
    width: 100px;
    font-size: 12px;
  }
}

.search-input:focus {
  outline: none;
  background-color: #f8f8f8;
  color: black;
}

.search_btn {
  height: inherit;
  width: 45px;
  border: none;
  background-color: white;
  border-left: 1px solid #e6e6e6;
  font-family: FontAwesome;
  font-size: 10px;
  color: #838383;
}

@media (max-width: 800px) {
  .searchForm button {
    font-size: 12px;
  }
}

</style>
